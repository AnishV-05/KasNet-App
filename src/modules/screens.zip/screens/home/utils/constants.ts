export const ERROR_RESPONSE_MESSAGES = {
    notFoundTaxpayer: "Taxpayer does not exists.",
    affiliateNotExists: "Referrer document number 21212121 does not exist in affiliater table"
}